package Service;

public class Server {

    ServerTime servertime = new ServerTime();

    //new一个出来
    public void newServer(){
        this.servertime.newServerTime();
    }

    //初始化归0
    public void initServer(){
        this.servertime.initServerTime();
    }

    //复制服务器信息
    public void copyServer(Server server){
        this.servertime.copyServerTime(server.servertime);
    }

}
