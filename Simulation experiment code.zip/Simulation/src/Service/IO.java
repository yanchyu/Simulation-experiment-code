package Service;

import java.sql.*;

public class IO {
    //读取数据并转化
    public void readandtranslate(int id,DAG dag,ServerCluster servercluster,double[][] struct,String tablename,Connection conn,PreparedStatement ps) throws Exception {
        String sql = "select subtasknum,servernum,dagstring,structstring from " + tablename + " where id = ?";
        ps = conn.prepareStatement(sql);
        ps.setInt(1,id);
        ResultSet resultSet = ps.executeQuery();
        resultSet.next();
        int subtasknum = resultSet.getInt("subtasknum");
        int servernum = resultSet.getInt("servernum");
        Blob b = resultSet.getBlob("dagstring");
        String dagstring = new String(b.getBytes(1, (int) b.length()),"utf-8");//blob 转 String
        String structstring = resultSet.getString("structstring");

        //转化DAG
        double[][] dagmatrix = new double[subtasknum+1][subtasknum+1];
        int d = 0;
        for(int i = 0;i <= subtasknum;i++){
            for (int j = 0; j <= subtasknum ; j++) {
                int bai = Integer.valueOf(dagstring.charAt(d)) - 48;
                d++;
                int shi = Integer.valueOf(dagstring.charAt(d)) - 48;
                d++;
                int ge = Integer.valueOf(dagstring.charAt(d)) - 48;
                d++;

                dagmatrix[i][j] = 100*bai + 10*shi + ge;
            }
        }
        dag.MatrixToDag(dagmatrix,subtasknum);

        //转化Servercluster
        servercluster.MatrixToServerCluster(servernum);

        //转化struct
        int st = 0;
        for(int i = 0;i <= subtasknum;i++){
            for (int j = 0; j <= servernum ; j++) {
                int wan = Integer.valueOf(structstring.charAt(st)) - 48;
                st++;
                int qian = Integer.valueOf(structstring.charAt(st)) - 48;
                st++;
                int bai = Integer.valueOf(structstring.charAt(st)) - 48;
                st++;
                int shi = Integer.valueOf(structstring.charAt(st)) - 48;
                st++;
                int ge = Integer.valueOf(structstring.charAt(st)) - 48;
                st++;
                struct[i][j] = 10000*wan + 1000*qian + 100*bai + 10*shi + ge;
            }
        }
    }


}
