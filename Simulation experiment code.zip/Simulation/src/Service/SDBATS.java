package Service;

public class SDBATS {
    public double SDBATSexe(DAG dag,ServerCluster servercluster,ServerCluster scf,double[][] struct,DOffload doffload){
//        scf.copyServerCluster(servercluster);
        //计算执行时间标准差sde
        double[] sde = new double[dag.subtasknum+1];//从1号位开始
        double[][] ET = new double[dag.subtasknum+1][servercluster.servernum+1];
        for (int i = 1; i <= dag.subtasknum ; i++) {
            double averageET = 0;
            for (int j = 1; j <= servercluster.servernum ; j++) {
                ET[i][j] = struct[i][j]*dag.subtask[i].calculation;
                averageET += ET[i][j];
            }
            averageET /= servercluster.servernum;
            for (int j = 1; j <= servercluster.servernum ; j++) {
                sde[i] += Math.pow((ET[i][j] - averageET),2);
            }
            sde[i] /= servercluster.servernum;
            sde[i] = Math.sqrt(sde[i]);
        }

//        //计算通讯时间标准差sdc
//        double sdc = 0;
//        double[] CT = new double[10000];//从1号位开始
//        double csum = 0;
//        int cnum = 0;
//        for (int d1 = 1; d1 <= dag.subtasknum ; d1++) {
//            for (int d2 = 1; d2 <= dag.subtask[d1].succnodenum ; d2++) {
//                int succ = dag.subtask[d1].succnode[d2];
//                for (int s1 = 1; s1 <= servercluster.servernum ; s1++) {
//                    for (int s2 = s1+1; s2 <= servercluster.servernum ; s2++) {
//                        cnum++;
//                        CT[cnum] = servercluster.server[s1].communication[s2] + dag.edge[d1][succ].communication/servercluster.server[s1].bandweight[s2];
//                        csum += CT[cnum];
//                    }
//                }
//            }
//        }
//        double averageCT = csum/cnum;
//        for (int i = 1; i <= cnum ; i++) {
//            sdc += Math.pow((CT[i] - averageCT),2);
//        }
//        sdc /= cnum;
//        sdc = Math.sqrt(sdc);


        //Rank值计算

        Rank(dag,sde);

        //建立待运行序列
        SubTaskInfo[] subinfo = new SubTaskInfo[100];
        for (int i = 0; i < subinfo.length; i++) {
            SubTaskInfo s = new SubTaskInfo();
            subinfo[i] = s;
            initinfonode(subinfo[i]);
        }

        //对第一个结点进行复制卸载
        for (int s = 1; s <= servercluster.servernum; s++) {
            double[] AT = doffload.Exe(1,s,dag,servercluster,struct);
            if(s != 1){
                dag.subtask[1].exedservernum++;
            }
            dag.subtask[1].AST[dag.subtask[1].exedservernum] = AT[0];
            dag.subtask[1].AFT[dag.subtask[1].exedservernum] = AT[1];
            dag.subtask[1].exedservername[dag.subtask[1].exedservernum] = s;
        }
        updatainfo(subinfo,dag);


        //按顺序放入服务器器集群进行执行
        while (dag.subtask[dag.subtasknum].exedservername[0] == 0) {
            scf.initServerCluster();
            scf.copyServerCluster(servercluster);

            //找到可用的第一个结点
            int exenodename = subinfo[1].taskname;


            int select = 1;
            double Eft = 999999;
            for (int j = 1; j <= scf.servernum; j++) {//遍历服务器

                scf.copyServerCluster(servercluster);

                double[] AT = doffload.Exe(exenodename,j,dag,scf ,struct);

                if(AT[1] < Eft){
                    Eft = AT[1];
                    select = j;
                }

            }


            double[] AT = doffload.Exe(exenodename,select,dag,servercluster,struct);
            dag.subtask[exenodename].AST[0] = AT[0];
            dag.subtask[exenodename].AFT[0] = AT[1];
            dag.subtask[exenodename].exedservername[0] = select;

//            System.out.println("第" + exenodename + "个任务 " + "AST:"+dag.subtask[exenodename].AST[0] + "  AFT:" + dag.subtask[exenodename].AFT[0]+" 服务器："+dag.subtask[exenodename].exedservername[0]);


            //更新辅助表
            delinfo(subinfo,exenodename);
            updatainfo(subinfo,dag);
        }

//        System.out.println("执行完成");
        return dag.subtask[dag.subtasknum].AFT[0];
    }


    //Rank计算
    public void Rank(DAG dag,double[] sde){
        for (int i = dag.subtasknum; i >= 1; i--) {
            if(i == dag.subtasknum){
                dag.subtask[i].rank = sde[i];
                continue;
            }
            //从后继结点中找最大值
            double max = -999999;
            for (int succ = 1; succ <= dag.subtask[i].succnodenum ; succ++) {
                int succnodename = dag.subtask[i].succnode[succ];
                double temp = dag.subtask[succnodename].rank + dag.edge[i][succnodename].communication;
                if (temp > max){
                    max = temp;
                }
            }
            dag.subtask[i].rank = sde[i] + max;
        }
    }

    //辅助信息单元
    public class SubTaskInfo{
        int taskname;
        double rank;
    }

    //初始化info单元
    public void initinfonode(SubTaskInfo subinfo){
        subinfo.taskname = 0;
        subinfo.rank = 0;
    }
    //复制info单元
    public void copyinfonode(SubTaskInfo SubInfo,SubTaskInfo subinfo){
        SubInfo.taskname = subinfo.taskname;
        SubInfo.rank = subinfo.rank;
    }

    //向info数组中添加新任务
    public void addinfo(SubTaskInfo[] subinfo,int subtaskname,DAG dag){
        subinfo[0].taskname++;
        subinfo[subinfo[0].taskname].taskname = subtaskname;
        subinfo[subinfo[0].taskname].rank = dag.subtask[subtaskname].rank;
    }

    //从info数组中删除任务
    public void delinfo(SubTaskInfo[] subinfo,int subtaskname){
        int select = 1;
        while (subinfo[select].taskname != subtaskname) select++;
        for (int i = select; i < subinfo[0].taskname; i++) {
            copyinfonode(subinfo[i],subinfo[i+1]);
        }
        initinfonode(subinfo[subinfo[0].taskname]);
        subinfo[0].taskname--;
    }

    //完全更新
    public void updatainfo(SubTaskInfo[] subinfo,DAG dag){
        for (int i = 1; i <= dag.subtasknum; i++) {
            if(dag.subtask[i].exedservername[0]!=0){
                continue;
            }
            int flag = 1 ;//0代表不可执行1代表可执行
            for (int j = 1; j <= dag.subtask[i].prednodenum ; j++) {
                if(dag.subtask[dag.subtask[i].prednode[j]].exedservername[0] == 0){
                    flag = 0;
                    break;
                }
            }
            if(flag == 1){
                if(!chectinfo(subinfo,i)){//不存在则添加
                    addinfo(subinfo,i,dag);
                }
            }

        }
        rankinfo(subinfo);
    }

    //对info数组进行排序
    public void rankinfo (SubTaskInfo[] subinfo){
        SubTaskInfo temp = new SubTaskInfo();
        for (int i = 1; i < subinfo[0].taskname; i++) {
            copyinfonode(temp,subinfo[i]);
            for (int j = i+1; j <= subinfo[0].taskname; j++) {
                if(subinfo[j].rank > temp.rank){
                    copyinfonode(subinfo[i],subinfo[j]);
                    copyinfonode(subinfo[j],temp);
                    copyinfonode(temp,subinfo[i]);
                }
            }
        }
    }

    //检查某一子任务是否存在
    public boolean chectinfo(SubTaskInfo[] subinfo,int subtaskname){
        boolean flag = false;
        for (int i = 1; i <= subinfo[0].taskname; i++) {
            if(subinfo[i].taskname == subtaskname){
                flag = true;
                break;
            }
        }
        return flag;
    }

}



