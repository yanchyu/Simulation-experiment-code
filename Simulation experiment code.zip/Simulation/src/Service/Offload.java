package Service;

public class Offload {
    public double[] Exe(int tasknumber,int servernumber,DAG dag,ServerCluster servercluster,double[][] struct){//返回AFT
        double taskneedtime = struct[tasknumber][servernumber]*dag.subtask[tasknumber].calculation;
        double taskavailtime = 0;
        //找taskavailtime
        double temp = 0;
        if(dag.subtask[tasknumber].prednodenum == 0){
            taskavailtime = 0;
        }else{
            taskavailtime = -999999;
            for (int i = 1; i <= dag.subtask[tasknumber].prednodenum; i++) {
                for (int j = 0; j <= dag.subtask[dag.subtask[tasknumber].prednode[i]].exedservernum; j++) {
                    if(servernumber == dag.subtask[dag.subtask[tasknumber].prednode[i]].exedservername[j]){
                        temp = dag.subtask[dag.subtask[tasknumber].prednode[i]].AFT[j];
                    }else{
                        temp = dag.subtask[dag.subtask[tasknumber].prednode[i]].AFT[j] + dag.edge[dag.subtask[tasknumber].prednode[i]][tasknumber].communication;
                    }
                    if(taskavailtime < temp){
                        taskavailtime = temp;
                    }
                }

            }
        }

        double AST = servercluster.server[servernumber].servertime.atCexe(taskneedtime,taskavailtime);
        double AFT = AST + taskneedtime;
        double[] AT = {AST,AFT};//0代表开始时间，1代表结束时间
        return AT;
    }

}
