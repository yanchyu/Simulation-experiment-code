package Service;


public class HLTSD {
    public double HLTSDexe(DAG dag,DAG df,ServerCluster servercluster,ServerCluster scf,double[][] struct,DOffload doffload){
        df.copyDag(dag);
        scf.copyServerCluster(servercluster);
        //计算平均和执行时间标准差sde
        double[] sde = new double[dag.subtasknum+1];//从1号位开始
        double[][] ET = new double[dag.subtasknum+1][servercluster.servernum+1];
        double[] averageET = new double[dag.subtasknum+1];
        for (int i = 1; i <= dag.subtasknum ; i++) {
            for (int j = 1; j <= servercluster.servernum ; j++) {
                ET[i][j] = struct[i][j]*dag.subtask[i].calculation;
                averageET[i] += ET[i][j];
            }
            averageET[i] /= servercluster.servernum;
            for (int j = 1; j <= servercluster.servernum ; j++) {
                sde[i] += Math.pow((ET[i][j] - averageET[i]),2);
            }
            sde[i] /= servercluster.servernum;
            sde[i] = Math.sqrt(sde[i]);
        }

        //计算后继通讯和sdc
        double[] sdc = new double[dag.subtasknum+1];//从1号位开始
        double[] occw = new double[dag.subtasknum+1];//从1号位开始
        double[] averageCT = new double[dag.subtasknum+1];//从1号位开始
        for (int i = 1; i <= dag.subtasknum ; i++) {
            //遍历后续结点求通讯和
            double[] succcomcost = new double[dag.subtask[i].succnodenum+1];//从1号位开始
            for (int succ = 1; succ <= dag.subtask[i].succnodenum; succ++) {
                int succnodename = dag.subtask[i].succnode[succ];
                succcomcost[succ] = dag.edge[i][succnodename].communication;
                occw[i] += succcomcost[succ];
            }
            //计算后继结点方差
            averageCT[i] = occw[i]/dag.subtask[i].succnodenum;
            for (int succ = 1; succ <= dag.subtask[i].succnodenum; succ++) {
                sdc[i] += Math.pow(succcomcost[succ]-averageCT[i],2);
            }
            sdc[i] /= dag.subtask[i].succnodenum;
            sdc[i] = Math.sqrt(sdc[i]);
        }

        //Rank值计算
        Rank(dag,sde,averageET,sdc,occw);

        //建立待运行序列
        SubTaskInfo[] subinfo = new SubTaskInfo[100];
        for (int i = 0; i < subinfo.length; i++) {
            SubTaskInfo s = new SubTaskInfo();
            subinfo[i] = s;
            initinfonode(subinfo[i]);
        }
        addinfo(subinfo,1,dag);

        //处理首结点及后继结点
        if(true) {
            //计算首结点在各个服务器上的执行时间
            double min = 999999;
            int entryselect = 0;
            double[] entryET = new double[servercluster.servernum + 1];//从1号位开始
            for (int s = 1; s <= servercluster.servernum; s++) {
                scf.copyServerCluster(servercluster);
                entryET[s] = doffload.Exe(1, s, dag, scf, struct)[1];
                if (entryET[s] < min) {
                    min = entryET[s];
                    entryselect = s;
                }
            }
            //对首结点最优服务器进行卸载
            double[] entryAT = doffload.Exe(1, entryselect, dag, servercluster, struct);
            dag.subtask[1].AST[dag.subtask[1].exedservernum] = entryAT[0];
            dag.subtask[1].AFT[dag.subtask[1].exedservernum] = entryAT[1];
            dag.subtask[1].exedservername[dag.subtask[1].exedservernum] = entryselect;

            delinfo(subinfo, 1);
            //更新后继结点
            updatainfo(subinfo, dag);

            for (int i = 1; i <= subinfo[0].taskname; i++) {
                //找到可用的第一个结点
                int exenodename = subinfo[1].taskname;
                double temp = 0;
                int flag = 0;
                int predtaskname = 0;
                int select = 1;
                double Oeft = 999999;
                for (int j = 1; j <= servercluster.servernum; j++) {//遍历服务器
                    df.copyDag(dag);
                    scf.copyServerCluster(servercluster);

                    double[] AT = doffload.Exe(exenodename,j,df,scf,struct);
                    temp = AT[1];
                    if(temp < Oeft){
                        Oeft = temp;
                        select = j;
                        flag = 0;
                    }

                    //查看当前服务器是否已经进行复制
                    int serverflag = 0;//0为没有复制，1为已复制
                    for (int exeserver = 0; exeserver <= dag.subtask[1].exedservernum ; exeserver++) {
                        if(j == dag.subtask[1].exedservername[exeserver]){
                            serverflag = 1;
                        }
                    }
                    if(serverflag == 1){
                        continue;
                    }

                    scf.copyServerCluster(servercluster);


                    //前置结点运行
                    int pred = (int)AT[2];
                    AT = doffload.Exe(pred,j,df,scf,struct);
                    df.subtask[pred].exedservernum++;
                    df.subtask[pred].AST[df.subtask[pred].exedservernum] = AT[0];
                    df.subtask[pred].AFT[df.subtask[pred].exedservernum] = AT[1];
                    df.subtask[pred].exedservername[df.subtask[pred].exedservernum] = j;


                    AT = doffload.Exe(exenodename, j, df, scf,struct);
                    temp = AT[1];
                    if (temp < Oeft) {
                        Oeft = temp;
                        select = j;
                        flag = 1;
                        predtaskname = pred;
                    }

                }

                if(flag == 0){
                    double[] AT = doffload.Exe(exenodename,select,dag,servercluster,struct);
                    dag.subtask[exenodename].AST[0] = AT[0];
                    dag.subtask[exenodename].AFT[0] = AT[1];
                    dag.subtask[exenodename].exedservername[0] = select;
                }
                if(flag == 1){
                    double[] AT = doffload.Exe(predtaskname,select,dag,servercluster,struct);
                    dag.subtask[predtaskname].exedservernum++;
                    dag.subtask[predtaskname].AST[dag.subtask[predtaskname].exedservernum] = AT[0];
                    dag.subtask[predtaskname].AFT[dag.subtask[predtaskname].exedservernum] = AT[1];
                    dag.subtask[predtaskname].exedservername[dag.subtask[predtaskname].exedservernum] = select;
                    AT = doffload.Exe(exenodename,select,dag,servercluster,struct);
                    dag.subtask[exenodename].AST[0] = AT[0];
                    dag.subtask[exenodename].AFT[0] = AT[1];
                    dag.subtask[exenodename].exedservername[0] = select;

                }
                delinfo(subinfo,exenodename);
            }
        }

        updatainfo(subinfo,dag);

        //按顺序放入服务器器集群进行执行
        while (dag.subtask[dag.subtasknum].exedservername[0] == 0) {

            //找到可用的第一个结点
            int exenodename = subinfo[1].taskname;

            double temp = 0;
            int flag = 0;
            int predtaskname = 0;
            int select = 1;
            double Oeft = 999999;
            for (int j = 1; j <= servercluster.servernum; j++) {//遍历服务器
                df.copyDag(dag);
                scf.copyServerCluster(servercluster);

                double[] AT = doffload.Exe(exenodename,j,df,scf,struct);
                temp = AT[1];
                if(temp < Oeft){
                    Oeft = temp;
                    select = j;
                    flag = 0;
                }

                scf.copyServerCluster(servercluster);

                //前置结点运行
                int pred = (int)AT[2];
                AT = doffload.Exe(pred,j,df,scf,struct);
                df.subtask[pred].exedservernum++;
                df.subtask[pred].AST[df.subtask[pred].exedservernum] = AT[0];
                df.subtask[pred].AFT[df.subtask[pred].exedservernum] = AT[1];
                df.subtask[pred].exedservername[df.subtask[pred].exedservernum] = j;


                AT = doffload.Exe(exenodename, j, df, scf,struct);
                temp = AT[1];
                if (temp < Oeft) {
                    Oeft = temp;
                    select = j;
                    flag = 1;
                    predtaskname = pred;
                }

            }

            if(flag == 0){
                double[] AT = doffload.Exe(exenodename,select,dag,servercluster,struct);
                dag.subtask[exenodename].AST[0] = AT[0];
                dag.subtask[exenodename].AFT[0] = AT[1];
                dag.subtask[exenodename].exedservername[0] = select;
            }
            if(flag == 1){
                double[] AT = doffload.Exe(predtaskname,select,dag,servercluster,struct);
                dag.subtask[predtaskname].exedservernum++;
                dag.subtask[predtaskname].AST[dag.subtask[predtaskname].exedservernum] = AT[0];
                dag.subtask[predtaskname].AFT[dag.subtask[predtaskname].exedservernum] = AT[1];
                dag.subtask[predtaskname].exedservername[dag.subtask[predtaskname].exedservernum] = select;
                AT = doffload.Exe(exenodename,select,dag,servercluster,struct);
                dag.subtask[exenodename].AST[0] = AT[0];
                dag.subtask[exenodename].AFT[0] = AT[1];
                dag.subtask[exenodename].exedservername[0] = select;

            }
            //更新辅助表
            delinfo(subinfo,exenodename);
            updatainfo(subinfo,dag);
        }
        return dag.subtask[dag.subtasknum].AFT[0];
    }

    //Rank计算
    public void Rank(DAG dag,double[] sde,double[] averageET,double[] sdc,double[] occw){
        for (int i = dag.subtasknum; i >= 1; i--) {
            if(i == dag.subtasknum){
                dag.subtask[i].rank = averageET[i];
                continue;
            }
            //从后继结点中找最大值
            double max = -999999;
            for (int succ = 1; succ <= dag.subtask[i].succnodenum ; succ++) {
                int succnodename = dag.subtask[i].succnode[succ];
                double temp =  dag.subtask[succnodename].rank;
                if (temp > max){
                    max = temp;
                }
            }
            dag.subtask[i].rank = averageET[i] + sde[i] + occw[i] + sdc[i] + max;
        }
    }

    //辅助信息单元
    public class SubTaskInfo{
        int taskname;
        double rank;
    }

    //初始化info单元
    public void initinfonode(SubTaskInfo subinfo){
        subinfo.taskname = 0;
        subinfo.rank = 0;
    }
    //复制info单元
    public void copyinfonode(SubTaskInfo SubInfo,SubTaskInfo subinfo){
        SubInfo.taskname = subinfo.taskname;
        SubInfo.rank = subinfo.rank;
    }

    //向info数组中添加新任务
    public void addinfo(SubTaskInfo[] subinfo,int subtaskname,DAG dag){
        subinfo[0].taskname++;
        subinfo[subinfo[0].taskname].taskname = subtaskname;
        subinfo[subinfo[0].taskname].rank = dag.subtask[subtaskname].rank;
    }

    //从info数组中删除任务
    public void delinfo(SubTaskInfo[] subinfo,int subtaskname){
        int select = 1;
        while (subinfo[select].taskname != subtaskname) select++;
        for (int i = select; i < subinfo[0].taskname; i++) {
            copyinfonode(subinfo[i],subinfo[i+1]);
        }
        initinfonode(subinfo[subinfo[0].taskname]);
        subinfo[0].taskname--;
    }

    //完全更新
    public void updatainfo(SubTaskInfo[] subinfo,DAG dag){
        for (int i = 1; i <= dag.subtasknum; i++) {
            if(dag.subtask[i].exedservername[0]!=0){
                continue;
            }
            int flag = 1 ;//0代表不可执行1代表可执行
            for (int j = 1; j <= dag.subtask[i].prednodenum ; j++) {
                if(dag.subtask[dag.subtask[i].prednode[j]].exedservername[0] == 0){
                    flag = 0;
                    break;
                }
            }
            if(flag == 1){
                if(!chectinfo(subinfo,i)){//不存在则添加
                    addinfo(subinfo,i,dag);
                }
            }

        }
        rankinfo(subinfo);
    }

    //对info数组进行排序
    public void rankinfo (SubTaskInfo[] subinfo){
        SubTaskInfo temp = new SubTaskInfo();
        for (int i = 1; i < subinfo[0].taskname; i++) {
            copyinfonode(temp,subinfo[i]);
            for (int j = i+1; j <= subinfo[0].taskname; j++) {
                if(subinfo[j].rank > temp.rank){
                    copyinfonode(subinfo[i],subinfo[j]);
                    copyinfonode(subinfo[j],temp);
                    copyinfonode(temp,subinfo[i]);
                }
            }
        }
    }

    //检查某一子任务是否存在
    public boolean chectinfo(SubTaskInfo[] subinfo,int subtaskname){
        boolean flag = false;
        for (int i = 1; i <= subinfo[0].taskname; i++) {
            if(subinfo[i].taskname == subtaskname){
                flag = true;
                break;
            }
        }
        return flag;
    }

}



