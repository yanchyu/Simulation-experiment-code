package Service;

import java.util.Objects;

public class SubTask {
    double calculation = 0;
    int[] exedservername = new int[101];//从0开始
    int exedservernum = 0;
    int prednodenum = 0;
    int[] prednode = new int[101];//从1开始
    int succnodenum = 0;
    int[] succnode = new int[101];//从1开始
    double[] AST = new double[101];//从0开始
    double[] AFT = new double[101];//从0开始
    double rank = 0;

    //prenode生成
    public void predadd(int i){
        int flag = 0;//是否已加入序列，1 已加入 0 没加入
        for (int j = 1; j <= prednodenum ; j++) {
            if(this.prednode[j] == i){
                flag = 1;
                break;
            }
        }
        if(flag == 0){
            this.prednode[prednodenum+1] = i;
            this.prednodenum++;
        }
    }
    //succnode生成
    public void succadd(int i){
        int flag = 0;//是否已加入序列，1 已加入 0 没加入
        for (int j = 1; j <= succnodenum ; j++) {
            if(this.succnode[j] == i){
                flag = 1;
                break;
            }
        }
        if(flag == 0){
            this.succnode[succnodenum+1] = i;
            this.succnodenum++;
        }
    }

    //初始化归0
    public void initSubTask(){
        this.calculation = 0;
        this.exedservernum = 0;
        for (int i = 0; i < this.exedservername.length; i++) {
            this.exedservername[i] = 0;
            this.AST[i] = 0;
            this.AFT[i] = 0;
        }

        this.prednodenum = 0;
        this.rank = 0;
        for (int i = 0; i < this.prednode.length; i++) {
            this.prednode[i] = 0;
        }
        this.succnodenum = 0;
        for (int i = 0; i < this.succnode.length; i++) {
            this.succnode[i] = 0;
        }
    }

    //复制子任务结点
    public void copySubTask(SubTask subtask){
        this.calculation = subtask.calculation;

        this.exedservernum = subtask.exedservernum;
        for (int i = 0; i < this.exedservername.length; i++) {
            this.exedservername[i] = subtask.exedservername[i];
            this.AST[i] = subtask.AST[i];
            this.AFT[i] = subtask.AFT[i];
        }

        this.prednodenum = subtask.prednodenum;
        for (int i = 0; i < this.prednode.length; i++) {
            this.prednode[i] = subtask.prednode[i];
        }
        this.succnodenum = subtask.succnodenum;
        for (int i = 0; i < this.succnode.length; i++) {
            this.succnode[i] = subtask.succnode[i];
        }
        this.rank = subtask.rank;
    }

}
