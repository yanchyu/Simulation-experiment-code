package Service;

public class AvailTime {
    double start;
    double end;
    double spare;
    int flag;//空闲1
    //对单个空闲时段进行操作
    public void setAvailTime(double start,double end){
        this.start = start;
        this.end = end;
        this.spare = end - start;
        this.flag = 1;
    }

    //空闲时段归0
    public void initAvailTime(){
        this.start = 0;
        this.end = 0;
        this.spare = 0;
        this.flag = 0;
    }

    //复制空闲时段
    public void copyAvailTime(AvailTime at){
        this.start = at.start;
        this.end = at.end;
        this.spare = at.spare;
        this.flag = at.flag;
    }

}

