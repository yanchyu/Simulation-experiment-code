package Service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class exe {
    public static void main(String[] args) throws Exception {
        //new可操作对象
        IO io = new IO();
        Offload offload = new Offload();
        DOffload doffload = new DOffload();
        DPLSpre DPLSpre = new DPLSpre();
        DPLSsec DPLSsec = new DPLSsec();
        PSLS psls = new PSLS();
        PEFT peft = new PEFT();
        HEFT heft = new HEFT();
        SDBATS sdbats = new SDBATS();
        HSIP hsip = new HSIP();
        HLTSD hltsd = new HLTSD();
        AVBS avbs = new AVBS();

        //评价指标
        CP cp = new CP();
        ST st = new ST();

        //生成DAG接收数据
        DAG dag = new DAG();
        dag.newDAG();
        dag.initDAG();
        DAG df = new DAG();
        df.newDAG();
        df.initDAG();
        DAG dff = new DAG();
        dff.newDAG();
        dff.initDAG();
        DAG dfff = new DAG();
        dfff.newDAG();
        dfff.initDAG();
        //生成ServerCluster接收数据
        ServerCluster servercluster = new ServerCluster();//服务器集群
        servercluster.newServerCluster();
        servercluster.initServerCluster();
        ServerCluster scf = new ServerCluster();//辅助集群
        scf.newServerCluster();
        scf.initServerCluster();
        ServerCluster scff = new ServerCluster();//辅助集群
        scff.newServerCluster();
        scff.initServerCluster();
        ServerCluster scfff = new ServerCluster();//辅助集群
        scfff.newServerCluster();
        scfff.initServerCluster();

        //数据库连接
        Class.forName("com.mysql.cj.jdbc.Driver");
        String url = "jdbc:mysql://127.0.0.1:3306/sample";
        String username = "root";
        String password = "12345";
        Connection conn = DriverManager.getConnection(url,username,password);
        PreparedStatement ps = null;

        //参数输入
        int[] tasknumarray = {10,20,30,40,50,60,70,80,90,100};
        int[] servernumarray = {5,10,15,20,25};
        double[] ccrarray = {0.2,0.5,1,2,5};
        double[] rangearray = {0.5,1,1.5};
        double[] fatarray = {0.3,0.5,0.7};
        double[] densityarray = {0.4,0.6};
        int tasknum,servernum;
        double ccr,range,fat,density;
        String tablename;
        double makespan;
        double[] makespanarray = {0,0};

        int dagnum = 100;
        //循环开始
        for (int tn = 0; tn < 10 ; tn++) {//子任务数量
            tasknum = tasknumarray[tn];
            for (int sn = 0; sn < 5; sn++) {//服务器数量
                servernum = servernumarray[sn];
                double[][] struct = new double[tasknum+1][servernum+1] ;//都从1开始计数
                for (int r = 0; r < 3; r++) {//range
                    range = rangearray[r];
                    for (int c = 0; c < 5; c++) {//ccr
                        ccr = ccrarray[c];
                        for (int f = 0; f < 3; f++) {//fat
                            fat = fatarray[f];
                            for (int d = 0; d < 2; d++) {//density
                                density = densityarray[d];
                                tablename = "tn" + tasknum + "_sn" + servernum + "_c" + (int)(ccr*10) + "_r" + (int)(range*10) + "_f" + (int)(fat*10) + "_d" + (int)(density*10);
                                for (int id = 1; id <= dagnum ; id++) {//每组参数100
                                    dag.initDAG();
                                    servercluster.initServerCluster();
                                    io.readandtranslate(id,dag,servercluster,struct,tablename,conn,ps);
                                    df.initDAG();
                                    df.copyDag(dag);
                                    dff.initDAG();
                                    dff.copyDag(dag);
                                    scf.initServerCluster();
                                    scf.copyServerCluster(servercluster);
                                    scff.initServerCluster();
                                    scff.copyServerCluster(servercluster);

                                    /**开始执行数据**/
                                    makespan = cp.CPexe(dag,servercluster,struct);
//                                    makespan = st.STexe(dag,servercluster,struct);
//                                    makespan = heft.HEFTexe(dag,servercluster,scf,struct,offload);
//                                    makespan = peft.PEFTexe(df,scf,scff,struct,offload);
//                                    makespanarray = psls.PSSSexe(dag,df,servercluster,scf,scff,struct,offload,peft);//已更改为max
//                                    makespan = hltsd.HLTSDexe(dag,df,servercluster,scf,struct,doffload);
//                                    makespan = sdbats.SDBATSexe(dag,servercluster,scf,struct,doffload);
//                                    makespan = hsip.HSIPSexe(dag,df,servercluster,scf,struct,doffload);
//                                    makespan = DPLSpre.DPLSpre(dag,df,servercluster,scf,struct,doffload);
//                                    makespanarray = DPLSsec.DPLSsec(dag,df,dff,servercluster,scf,scff,struct,doffload,DPLSpre);
//                                    makespan = avbs.MIXexe(dag,df,servercluster,scf,scff,struct,offload);

                                    /**写入执行结果**/
                                    String sql_write = "update " + tablename + " set a1 = " + makespan + " where id = " + id;
                                    ps = conn.prepareStatement(sql_write);
                                    ps.execute();
                                }//每组参数100
                            }//density
                        }//fat
                        System.out.println("" + tn + " " + sn + " " + r + " " + c);
                    }//ccr
                }//range
            }//服务器数量
        }//子任务数量

        //断开数据库
        ps.close();
        conn.close();

    }//main方法结束

}//类结束
