package Service;
//预调度：  不包括当前结点计算开销  通讯不使用平均值
//二次调度：包括当前结点计算开销  通讯不使用平均值

public class DPLSsec {
    public double[] DPLSsec(DAG dag, DAG df, DAG dff, ServerCluster servercluster, ServerCluster scf, ServerCluster scff, double[][] struct, DOffload doffload, DPLSpre DPLSpre) {
//        df.copyDag(dag);
//        dff.copyDag(dag);
//        scf.copyServerCluster(servercluster);
//        scff.copyServerCluster(servercluster);
        //建立待运行序列
        SubTaskInfo[] subinfo = new SubTaskInfo[100];
        for (int i = 0; i < subinfo.length; i++) {
            SubTaskInfo s = new SubTaskInfo();
            subinfo[i] = s;
            initinfonode(subinfo[i]);
        }
        addinfo(subinfo, 1, dag);


        //用预调度算法对df进行预调度
        df.copyDag(dag);
        scf.copyServerCluster(servercluster);
        double makespanDplsPre = DPLSpre.DPLSpre(df,dff,scf,scff,struct,doffload);

        //获取LAT表
        double[][] lat = new double[dag.subtasknum + 1][servercluster.servernum + 1];//从1开始
        LAT(df, scf, lat);

        //Rank值计算
        Rank(dag, scf,struct, lat);

        //按顺序放入服务器器集群进行执行
        while (dag.subtask[dag.subtasknum].exedservername[0] == 0) {
            //找到可用的第一个结点
            int exenodename = subinfo[1].taskname;

            double temp = 0;
            int flag = 0;
            int predtaskname = 0;
            int select = 1;
            double Oeft = 999999;
            for (int j = 1; j <= servercluster.servernum; j++) {//遍历服务器
                df.copyDag(dag);
                scf.copyServerCluster(servercluster);

                double[] AT = doffload.Exe(exenodename, j, df, scf, struct);
                temp = AT[1] + lat[exenodename][j];
                if (temp < Oeft) {
                    Oeft = temp;
                    select = j;
                    flag = 0;
                }

                scf.copyServerCluster(servercluster);

                //前置结点运行
                int pred = (int) AT[2];
                AT = doffload.Exe(pred, j, df, scf, struct);
                df.subtask[pred].exedservernum++;
                df.subtask[pred].AST[df.subtask[pred].exedservernum] = AT[0];
                df.subtask[pred].AFT[df.subtask[pred].exedservernum] = AT[1];
                df.subtask[pred].exedservername[df.subtask[pred].exedservernum] = j;

                AT = doffload.Exe(exenodename, j, df, scf, struct);
                temp = AT[1] + lat[exenodename][j];
                if (temp < Oeft) {
                    Oeft = temp;
                    select = j;
                    flag = 1;
                    predtaskname = pred;
                }
            }

            if (flag == 0) {
                double[] AT = doffload.Exe(exenodename, select, dag, servercluster, struct);
                dag.subtask[exenodename].AST[0] = AT[0];
                dag.subtask[exenodename].AFT[0] = AT[1];
                dag.subtask[exenodename].exedservername[0] = select;
            }
            if(flag == 1){
                double[] AT = doffload.Exe(predtaskname, select, dag, servercluster, struct);
                dag.subtask[predtaskname].exedservernum++;
                dag.subtask[predtaskname].AST[dag.subtask[predtaskname].exedservernum] = AT[0];
                dag.subtask[predtaskname].AFT[dag.subtask[predtaskname].exedservernum] = AT[1];
                dag.subtask[predtaskname].exedservername[dag.subtask[predtaskname].exedservernum] = select;
                AT = doffload.Exe(exenodename, select, dag, servercluster, struct);
                dag.subtask[exenodename].AST[0] = AT[0];
                dag.subtask[exenodename].AFT[0] = AT[1];
                dag.subtask[exenodename].exedservername[0] = select;

            }
            //更新辅助表
            delinfo(subinfo, exenodename);
            updatainfo(subinfo, dag);
        }

        double makespanDplsSec;
        if(makespanDplsPre < dag.subtask[dag.subtasknum].AFT[0]){
            makespanDplsSec = makespanDplsPre;
        }else {
            makespanDplsSec = dag.subtask[dag.subtasknum].AFT[0];
        }
        double[] re = {makespanDplsPre,makespanDplsSec};
        return re;
    }

    //Rank计算
    public void Rank(DAG dag,ServerCluster servercluster,double[][] struct,double[][] lat){
        for (int i = 1; i <= dag.subtasknum; i++) {
            double sum = 0;
            for (int j = 1; j <= servercluster.servernum; j++) {
                sum = sum + lat[i][j] + struct[i][j]*dag.subtask[i].calculation;
            }
            dag.subtask[i].rank = sum/servercluster.servernum;
        }
    }

    //辅助信息单元
    public class SubTaskInfo{
        int taskname;
        double rank;
    }

    //初始化info单元
    public void initinfonode(SubTaskInfo subinfo){
        subinfo.taskname = 0;
        subinfo.rank = 0;
    }
    //复制info单元
    public void copyinfonode(SubTaskInfo SubInfo,SubTaskInfo subinfo){
        SubInfo.taskname = subinfo.taskname;
        SubInfo.rank = subinfo.rank;
    }

    //向info数组中添加新任务
    public void addinfo(SubTaskInfo[] subinfo,int subtaskname,DAG dag){
        subinfo[0].taskname++;
        subinfo[subinfo[0].taskname].taskname = subtaskname;
        subinfo[subinfo[0].taskname].rank = dag.subtask[subtaskname].rank;
    }

    //从info数组中删除任务
    public void delinfo(SubTaskInfo[] subinfo,int subtaskname){
        int select = 1;
        while (subinfo[select].taskname != subtaskname) select++;
        for (int i = select; i < subinfo[0].taskname; i++) {
            copyinfonode(subinfo[i],subinfo[i+1]);
        }
        initinfonode(subinfo[subinfo[0].taskname]);
        subinfo[0].taskname--;
    }

    //完全更新
    public void updatainfo(SubTaskInfo[] subinfo,DAG dag){
        for (int i = 1; i <= dag.subtasknum; i++) {
            if(dag.subtask[i].exedservername[0]!=0){
                continue;
            }
            int flag = 1 ;//0代表不可执行1代表可执行
            for (int j = 1; j <= dag.subtask[i].prednodenum ; j++) {
                if(dag.subtask[dag.subtask[i].prednode[j]].exedservername[0] == 0){
                    flag = 0;
                    break;
                }
            }
            if(flag == 1){
                if(!chectinfo(subinfo,i)){//不存在则添加
                    addinfo(subinfo,i,dag);
                }
            }

        }
        rankinfo(subinfo);
    }

    //对info数组进行排序
    public void rankinfo (SubTaskInfo[] subinfo){
        SubTaskInfo temp = new SubTaskInfo();
        for (int i = 1; i < subinfo[0].taskname; i++) {
            copyinfonode(temp,subinfo[i]);
            for (int j = i+1; j <= subinfo[0].taskname; j++) {
                if(subinfo[j].rank > temp.rank){
                    copyinfonode(subinfo[i],subinfo[j]);
                    copyinfonode(subinfo[j],temp);
                    copyinfonode(temp,subinfo[i]);
                }
            }
        }
    }

    //检查某一子任务是否存在
    public boolean chectinfo(SubTaskInfo[] subinfo,int subtaskname){
        boolean flag = false;
        for (int i = 1; i <= subinfo[0].taskname; i++) {
            if(subinfo[i].taskname == subtaskname){
                flag = true;
                break;
            }
        }
        return flag;
    }

    //DLT计算
    public void LAT(DAG dag,ServerCluster servercluster,double[][] lat){
        double makespan = dag.subtask[dag.subtasknum].AFT[0];
        for (int i = 1; i <= dag.subtasknum; i++) {
            for (int j = 1; j <= servercluster.servernum ; j++) {
                if(dag.subtask[i].succnodenum == 0){
                    lat[i][j] = 0;
                    continue;
                }
                //从后继节点中找max
                double min = 999999;
                for (int succ = 1; succ <= dag.subtask[i].succnodenum; succ++) {//succ为后继节点数组序号
                    int succnodename = dag.subtask[i].succnode[succ];
                    int sj = dag.subtask[succnodename].exedservername[0];//后继结点的服务器
                    double temp = dag.subtask[succnodename].AST[0];
                    if(j != sj){
                        temp = temp - dag.edge[i][succnodename].communication;
                    }
                    if(temp < min){
                        min = temp;
                    }
                }
                lat[i][j] = makespan - min;
            }//服务器遍历结束
        }//结点遍历结束
    }

}



