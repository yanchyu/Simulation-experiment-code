package Service;

public class ServerCluster {
    int servernum = 0;
    Server[] server = new Server[31];

    //new一个出来
    public void newServerCluster(){
        this.servernum = 0;
        for (int i = 0; i < this.server.length; i++) {
            Server serverobject = new Server();
            serverobject.newServer();
            this.server[i] = serverobject;//new一个服务器对象给数组元素
        }
    }

    //初始化归0
    public void initServerCluster(){
        this.servernum = 0;
        for (int i = 0; i < this.server.length; i++) {
            this.server[i].initServer();
        }
    }

    //从数组中读取服务器数据读取
    public void MatrixToServerCluster(int servernum){
        this.servernum = servernum;
    }

    //复制服务器集群信息
    public void copyServerCluster(ServerCluster servercluster){
        this.servernum = servercluster.servernum;
        for (int i = 0; i < this.server.length; i++) {
            this.server[i].copyServer(servercluster.server[i]);
        }
    }
}
