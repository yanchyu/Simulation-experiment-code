package Service;

public class PEFT {
    public double PEFTexe(DAG dag,ServerCluster servercluster,ServerCluster scf,double[][] struct,Offload offload){
//        scf.copyServerCluster(servercluster);

        //获取OCT
        double[][] oct = new double[dag.subtasknum+1][servercluster.servernum+1];//行列都从1开始
        OCT(dag,servercluster,struct,oct);

        //Rank值计算
        Rank(dag,servercluster,oct);


        //建立待运行序列
        SubTaskInfo[] subinfo = new SubTaskInfo[101];
        for (int i = 0; i < subinfo.length; i++) {
            SubTaskInfo s = new SubTaskInfo();
            subinfo[i] = s;
            initinfonode(subinfo[i]);
        }
        addinfo(subinfo,1,dag);

        //按顺序放入服务器器集群进行执行
        while (dag.subtask[dag.subtasknum].exedservername[0] == 0) {
            scf.copyServerCluster(servercluster);

            //找到可用的第一个结点
            int exenodename = subinfo[1].taskname;

            double temp = 0;
            int select = 1;
            double Oeft = 999999;
            for (int j = 1; j <= scf.servernum; j++) {//遍历服务器
                scf.copyServerCluster(servercluster);

                double[] AT = offload.Exe(exenodename,j,dag,scf ,struct);
                temp = AT[1] + oct[exenodename][j];
                if(temp < Oeft){
                    Oeft = temp;
                    select = j;
                }

            }

            double[] AT = offload.Exe(exenodename,select,dag,servercluster,struct);
            dag.subtask[exenodename].AST[0] = AT[0];
            dag.subtask[exenodename].AFT[0] = AT[1];
            dag.subtask[exenodename].exedservername[0] = select;

            //更新辅助表
            delinfo(subinfo,exenodename);
            updatainfo(subinfo,dag);
        }
//        System.out.println("执行完成");
        return dag.subtask[dag.subtasknum].AFT[0];
    }

    //OCT表计算-
    public void OCT(DAG dag,ServerCluster servercluster,double[][] struct,double[][] oct){
        for (int i = dag.subtasknum; i >= 1; i--) {
            for (int j = 1; j <= servercluster.servernum; j++) {
                if (dag.subtask[i].succnodenum == 0){
                    oct[i][j] = 0;
                    continue;
                }
                //遍历后继结点找最大值
                double max = -999999;
                for (int succ = 1; succ <= dag.subtask[i].succnodenum ; succ++) {
                    //遍历后继服务器找最小值
                    double min = 999999;
                    for (int sj = 1; sj <= servercluster.servernum ; sj++) {
                        double temp = oct[dag.subtask[i].succnode[succ]][sj]
                                + struct[dag.subtask[i].succnode[succ]][sj]*dag.subtask[dag.subtask[i].succnode[succ]].calculation;//执行时延
                        if(j != sj){
                            temp = temp + dag.edge[i][dag.subtask[i].succnode[succ]].communication;//通讯时延
                        }
                        if (temp < min){
                            min = temp;
                        }
                    }
                    if (min > max){
                        max = min;
                    }
                }
                oct[i][j] = max;
            }//当前结点服务器循环结束
        }//结点循环结束
    }//OCT方法结束

    //Rank计算
    public void Rank(DAG dag,ServerCluster servercluster,double[][] oct){
        for (int i = 1; i <= dag.subtasknum; i++) {
            double sum = 0;
            for (int j = 1; j <= servercluster.servernum; j++) {
                sum = sum + oct[i][j];
            }
            dag.subtask[i].rank = sum/servercluster.servernum;
        }
    }

    //辅助信息单元
    public class SubTaskInfo{
        int taskname;
        double rank;
    }

    //初始化info单元
    public void initinfonode(SubTaskInfo subinfo){
        subinfo.taskname = 0;
        subinfo.rank = 0;
    }
    //复制info单元
    public void copyinfonode(SubTaskInfo SubInfo,SubTaskInfo subinfo){
        SubInfo.taskname = subinfo.taskname;
        SubInfo.rank = subinfo.rank;
    }

    //向info数组中添加新任务
    public void addinfo(SubTaskInfo[] subinfo,int subtaskname,DAG dag){
        subinfo[0].taskname++;
        subinfo[subinfo[0].taskname].taskname = subtaskname;
        subinfo[subinfo[0].taskname].rank = dag.subtask[subtaskname].rank;
    }

    //从info数组中删除任务
    public void delinfo(SubTaskInfo[] subinfo,int subtaskname){
        int select = 1;
        while (subinfo[select].taskname != subtaskname) select++;
        for (int i = select; i < subinfo[0].taskname; i++) {
            copyinfonode(subinfo[i],subinfo[i+1]);
        }
        initinfonode(subinfo[subinfo[0].taskname]);
        subinfo[0].taskname--;
    }

    //完全更新
    public void updatainfo(SubTaskInfo[] subinfo,DAG dag){
        for (int i = 1; i <= dag.subtasknum; i++) {
            if(dag.subtask[i].exedservername[0]!=0){
                continue;
            }
            int flag = 1 ;//0代表不可执行1代表可执行
            for (int j = 1; j <= dag.subtask[i].prednodenum ; j++) {
                if(dag.subtask[dag.subtask[i].prednode[j]].exedservername[0] == 0){
                    flag = 0;
                    break;
                }
            }
            if(flag == 1){
                if(!chectinfo(subinfo,i)){//不存在则添加
                    addinfo(subinfo,i,dag);
                }
            }

        }
        rankinfo(subinfo);
    }

    //对info数组进行排序
    public void rankinfo (SubTaskInfo[] subinfo){
        SubTaskInfo temp = new SubTaskInfo();
        for (int i = 1; i < subinfo[0].taskname; i++) {
            copyinfonode(temp,subinfo[i]);
            for (int j = i+1; j <= subinfo[0].taskname; j++) {
                if(subinfo[j].rank > temp.rank){
                    copyinfonode(subinfo[i],subinfo[j]);
                    copyinfonode(subinfo[j],temp);
                    copyinfonode(temp,subinfo[i]);
                }
            }
        }
    }

    //检查某一子任务是否存在
    public boolean chectinfo(SubTaskInfo[] subinfo,int subtaskname){
        boolean flag = false;
        for (int i = 1; i <= subinfo[0].taskname; i++) {
            if(subinfo[i].taskname == subtaskname){
                flag = true;
                break;
            }
        }
        return flag;
    }

}


