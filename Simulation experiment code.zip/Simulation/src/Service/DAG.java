package Service;

public class DAG {
    int subtasknum = 0;
    SubTask[] subtask = new SubTask[101];//保持一致
    Edge[][] edge = new Edge[101][101];//保持一致

    //new一个DAG
    public void newDAG(){
        this.subtasknum = 0;
        for (int i = 0; i < this.subtask.length; i++) {
            SubTask subtaskobject = new SubTask();
            this.subtask[i] = subtaskobject;
            for (int j = 0; j < this.edge.length; j++) {
                Edge edgeobject = new Edge();
                this.edge[i][j] = edgeobject;
            }
        }
    }

    //DAG初始化归0
    public void initDAG(){
        this.subtasknum = 0;
        for (int i = 0; i < this.subtask.length; i++) {
            this.subtask[i].initSubTask();
            for (int j = 0; j < this.edge[i].length; j++) {
                edge[i][j].initEdge();
            }
        }
    }

    //DAG读取
    public void MatrixToDag(double[][] dagmatrix,int subtasknum){
        this.subtasknum = subtasknum;
        for (int j = 1; j <= this.subtasknum; j++) {//新增结点
            this.subtask[j].calculation = dagmatrix[0][j];//添加计算量
            for(int i =1; i <= this.subtasknum;i++){//新增边缘和前后继结点信息
                if(dagmatrix[i][j] != 0){
                    this.edge[i][j].communication = dagmatrix[i][j];//添加数据量
                    this.subtask[j].predadd(i);//添加前后继
                    this.subtask[i].succadd(j);
                }
            }
        }
    }

    //DAG复制
    public void copyDag(DAG dag){
        this.subtasknum = dag.subtasknum;
        for (int i = 0; i < this.subtask.length; i++) {
            this.subtask[i].copySubTask(dag.subtask[i]);
            for (int j = 0; j < this.edge.length; j++) {
                this.edge[i][j].copyEdge(dag.edge[i][j]);
            }
        }
    }

}
