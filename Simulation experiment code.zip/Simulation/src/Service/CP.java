package Service;

public class CP {
    public double CPexe(DAG dag,ServerCluster servercluster,double[][] struct){
        double[] RC = new double[dag.subtasknum+1];//从1号位开始
        for (int i = dag.subtasknum; i >= 1; i--) {
            //计算当前结点最小执行时间
            double minET = 99999999;
            for (int j = 1; j <= servercluster.servernum; j++) {
                double ET = struct[i][j]*dag.subtask[i].calculation;
                if(ET < minET){
                    minET = ET;
                }
            }

            //尾结点
            if (dag.subtask[i].succnodenum == 0){
                RC[i] = minET;
                continue;
            }

            //遍历后继结点找最大值
            double max = -999999;
            for (int succ = 1; succ <= dag.subtask[i].succnodenum ; succ++) {
                int succnode = dag.subtask[i].succnode[succ];
                double temp = RC[succnode];
                if(temp > max){
                    max = temp;
                }
            }
            RC[i] = minET + max;
        }//结点循环结束
        return RC[1];
    }//方法结束

}
