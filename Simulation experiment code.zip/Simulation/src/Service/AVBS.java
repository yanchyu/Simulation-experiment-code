package Service;

public class AVBS {

    public double MIXexe(DAG dag,DAG df,ServerCluster servercluster,ServerCluster scf,ServerCluster scff,double[][] struct,Offload offload){

        double AVBSmakespan = AVBSexe(df,scf,scff,struct,offload);
        df.initDAG();
        df.copyDag(dag);
        scf.initServerCluster();
        scf.copyServerCluster(servercluster);
        scff.initServerCluster();
        scff.copyServerCluster(servercluster);
        double MXCTmakespan = MXCTexe(df,scf,scff,struct,offload);
        df.initDAG();
        df.copyDag(dag);
        scf.initServerCluster();
        scf.copyServerCluster(servercluster);
        scff.initServerCluster();
        scff.copyServerCluster(servercluster);
        double MNCTmakespan = MNCTexe(df,scf,scff,struct,offload);

        double minMakespan = AVBSmakespan;
        if(MXCTmakespan < minMakespan){
            minMakespan = MXCTmakespan;
        }
        if(MNCTmakespan < minMakespan){
            minMakespan = MNCTmakespan;
        }

        return minMakespan;

    }

    public double AVBSexe(DAG dag,ServerCluster servercluster,ServerCluster scf,double[][] struct,Offload offload){
        //计算平均执行时间
        double[] ET = new double[dag.subtasknum+1];
        for (int i = 1; i <= dag.subtasknum ; i++) {
            for (int j = 1; j <= servercluster.servernum ; j++) {
                ET[i] += struct[i][j]*dag.subtask[i].calculation;
            }
            ET[i] /= servercluster.servernum;
        }

        //Rank值计算
        Rank(dag,ET);

        //建立待运行序列
        SubTaskInfo[] subinfo = new SubTaskInfo[100];
        for (int i = 0; i < subinfo.length; i++) {
            SubTaskInfo s = new SubTaskInfo();
            subinfo[i] = s;
            initinfonode(subinfo[i]);
        }
        addinfo(subinfo,1,dag);

        //按顺序放入服务器器集群进行执行

        while (dag.subtask[dag.subtasknum].exedservername[0] == 0) {
            scf.copyServerCluster(servercluster);

            //找到可用的第一个结点
            int exenodename = subinfo[1].taskname;

            double temp = 0;
            int select = 1;
            double Oeft = 999999;
            for (int j = 1; j <= scf.servernum; j++) {//遍历服务器
                scf.copyServerCluster(servercluster);
                double[] AT = offload.Exe(exenodename,j,dag,scf,struct);

                temp = AT[1];
                if(temp < Oeft){
                    Oeft = temp;
                    select = j;
                }

            }

            double[] AT = offload.Exe(exenodename,select,dag,servercluster,struct);
            dag.subtask[exenodename].AST[0] = AT[0];
            dag.subtask[exenodename].AFT[0] = AT[1];
            dag.subtask[exenodename].exedservername[0] = select;

            //更新辅助表
            delinfo(subinfo,exenodename);
            updatainfo(subinfo,dag);
        }

        return dag.subtask[dag.subtasknum].AFT[0];
    }

    public double MXCTexe(DAG dag,ServerCluster servercluster,ServerCluster scf,double[][] struct,Offload offload){
        //计算最大执行时间
        double[] ET = new double[dag.subtasknum+1];
        for (int i = 1; i <= dag.subtasknum ; i++) {
            ET[i] = struct[i][1]*dag.subtask[i].calculation;
            for (int j = 2; j <= servercluster.servernum ; j++) {
                double maxcost = struct[i][j]*dag.subtask[i].calculation;
                if(maxcost > ET[i]){
                    ET[i] = maxcost;
                }
            }
        }

        //Rank值计算
        Rank(dag,ET);

        //建立待运行序列
        SubTaskInfo[] subinfo = new SubTaskInfo[100];
        for (int i = 0; i < subinfo.length; i++) {
            SubTaskInfo s = new SubTaskInfo();
            subinfo[i] = s;
            initinfonode(subinfo[i]);
        }
        addinfo(subinfo,1,dag);

        //按顺序放入服务器器集群进行执行

        while (dag.subtask[dag.subtasknum].exedservername[0] == 0) {
            scf.copyServerCluster(servercluster);

            //找到可用的第一个结点
            int exenodename = subinfo[1].taskname;

            double temp = 0;
            int select = 1;
            double Oeft = 999999;
            for (int j = 1; j <= scf.servernum; j++) {//遍历服务器
                scf.copyServerCluster(servercluster);
                double[] AT = offload.Exe(exenodename,j,dag,scf,struct);

                temp = AT[1];
                if(temp < Oeft){
                    Oeft = temp;
                    select = j;
                }

            }

            double[] AT = offload.Exe(exenodename,select,dag,servercluster,struct);
            dag.subtask[exenodename].AST[0] = AT[0];
            dag.subtask[exenodename].AFT[0] = AT[1];
            dag.subtask[exenodename].exedservername[0] = select;

            //更新辅助表
            delinfo(subinfo,exenodename);
            updatainfo(subinfo,dag);
        }

        return dag.subtask[dag.subtasknum].AFT[0];
    }

    public double MNCTexe(DAG dag,ServerCluster servercluster,ServerCluster scf,double[][] struct,Offload offload){
        //计算最小执行时间
        double[] ET = new double[dag.subtasknum+1];
        for (int i = 1; i <= dag.subtasknum ; i++) {
            ET[i] = struct[i][1]*dag.subtask[i].calculation;
            for (int j = 2; j <= servercluster.servernum ; j++) {
                double mincost = struct[i][j]*dag.subtask[i].calculation;
                if(mincost < ET[i]){
                    ET[i] = mincost;
                }
            }
        }

        //Rank值计算
        Rank(dag,ET);

        //建立待运行序列
        SubTaskInfo[] subinfo = new SubTaskInfo[100];
        for (int i = 0; i < subinfo.length; i++) {
            SubTaskInfo s = new SubTaskInfo();
            subinfo[i] = s;
            initinfonode(subinfo[i]);
        }
        addinfo(subinfo,1,dag);

        //按顺序放入服务器器集群进行执行

        while (dag.subtask[dag.subtasknum].exedservername[0] == 0) {
            scf.copyServerCluster(servercluster);

            //找到可用的第一个结点
            int exenodename = subinfo[1].taskname;

            double temp = 0;
            int select = 1;
            double Oeft = 999999;
            for (int j = 1; j <= scf.servernum; j++) {//遍历服务器
                scf.copyServerCluster(servercluster);
                double[] AT = offload.Exe(exenodename,j,dag,scf,struct);

                temp = AT[1];
                if(temp < Oeft){
                    Oeft = temp;
                    select = j;
                }

            }

            double[] AT = offload.Exe(exenodename,select,dag,servercluster,struct);
            dag.subtask[exenodename].AST[0] = AT[0];
            dag.subtask[exenodename].AFT[0] = AT[1];
            dag.subtask[exenodename].exedservername[0] = select;

            //更新辅助表
            delinfo(subinfo,exenodename);
            updatainfo(subinfo,dag);
        }

        return dag.subtask[dag.subtasknum].AFT[0];
    }


    //Rank计算
    public void Rank(DAG dag,double[] ET){
        for (int i = dag.subtasknum; i >= 1; i--) {
            if (dag.subtask[i].succnodenum == 0){
                dag.subtask[i].rank = ET[i];
                continue;
            }
            //遍历后继结点找最大值
            double max = -999999;
            for (int succ = 1; succ <= dag.subtask[i].succnodenum ; succ++) {
                int succnodename = dag.subtask[i].succnode[succ];
                double temp = ET[i] + dag.edge[i][succnodename].communication + dag.subtask[succnodename].rank;
                if(temp > max){
                    max = temp;
                }
            }
            dag.subtask[i].rank = max;
        }//结点循环结束
    }

    //辅助信息单元
    public class SubTaskInfo{
        int taskname;
        double rank;
    }

    //初始化info单元
    public void initinfonode(SubTaskInfo subinfo){
        subinfo.taskname = 0;
        subinfo.rank = 0;
    }
    //复制info单元
    public void copyinfonode(SubTaskInfo SubInfo,SubTaskInfo subinfo){
        SubInfo.taskname = subinfo.taskname;
        SubInfo.rank = subinfo.rank;
    }

    //向info数组中添加新任务
    public void addinfo(SubTaskInfo[] subinfo,int subtaskname,DAG dag){
        subinfo[0].taskname++;
        subinfo[subinfo[0].taskname].taskname = subtaskname;
        subinfo[subinfo[0].taskname].rank = dag.subtask[subtaskname].rank;
    }

    //从info数组中删除任务
    public void delinfo(SubTaskInfo[] subinfo,int subtaskname){
        int select = 1;
        while (subinfo[select].taskname != subtaskname) select++;
        for (int i = select; i < subinfo[0].taskname; i++) {
            copyinfonode(subinfo[i],subinfo[i+1]);
        }
        initinfonode(subinfo[subinfo[0].taskname]);
        subinfo[0].taskname--;
    }

    //完全更新
    public void updatainfo(SubTaskInfo[] subinfo,DAG dag){
        for (int i = 1; i <= dag.subtasknum; i++) {
            if(dag.subtask[i].exedservername[0]!=0){
                continue;
            }
            int flag = 1 ;//0代表不可执行1代表可执行
            for (int j = 1; j <= dag.subtask[i].prednodenum ; j++) {
                if(dag.subtask[dag.subtask[i].prednode[j]].exedservername[0] == 0){
                    flag = 0;
                    break;
                }
            }
            if(flag == 1){
                if(!chectinfo(subinfo,i)){//不存在则添加
                    addinfo(subinfo,i,dag);
                }
            }

        }
        rankinfo(subinfo);
    }

    //对info数组进行排序
    public void rankinfo (SubTaskInfo[] subinfo){
        SubTaskInfo temp = new SubTaskInfo();
        for (int i = 1; i < subinfo[0].taskname; i++) {
            copyinfonode(temp,subinfo[i]);
            for (int j = i+1; j <= subinfo[0].taskname; j++) {
                if(subinfo[j].rank > temp.rank){
                    copyinfonode(subinfo[i],subinfo[j]);
                    copyinfonode(subinfo[j],temp);
                    copyinfonode(temp,subinfo[i]);
                }
            }
        }
    }

    //检查某一子任务是否存在
    public boolean chectinfo(SubTaskInfo[] subinfo,int subtaskname){
        boolean flag = false;
        for (int i = 1; i <= subinfo[0].taskname; i++) {
            if(subinfo[i].taskname == subtaskname){
                flag = true;
                break;
            }
        }
        return flag;
    }

}



