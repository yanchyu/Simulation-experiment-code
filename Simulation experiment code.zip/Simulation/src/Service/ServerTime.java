package Service;

import java.lang.reflect.Array;
import java.util.Arrays;

public class ServerTime {
    double timerange = 0;//timrange[0]代表处理机时间，timerange[1]代表带宽时间
    AvailTime[] atc = new AvailTime[101];//从atc[0]开始
//    AvailTime[] atb = new AvailTime[100];

    public double atCexe(double taskneedtime,double taskavailtime){
        double AST = 0;
        int select = 0;//是否命中时间段 1：命中 0：没命中
        int i = 0;
        while (this.atc[i].flag == 1) {
            if(this.atc[i].end - taskavailtime >= taskneedtime & this.atc[i].spare >= taskneedtime){//命中进行处理
                if(this.atc[i].start > taskavailtime){//从空闲时间段头部进行处理
//                    at[i].start += taskneedtime;
//                    at[i].spare = at[i].end - at[i].start;
//                    at[i].flag = 1;
                    this.atc[i].setAvailTime(this.atc[i].start + taskneedtime,this.atc[i].end);
                    AST = this.atc[i].start;//返回值
                    select = 1;
                    break;
                }else{//从空闲时间段中部开始处理，并诞生两条空闲
                    int j = i;//每一段往后挪
                    while(this.atc[j].flag == 1){
                        j++;
                    }//j为第一个非空闲段
                    for (; j >= i+2 ; j--) {
//                        at[j].start = at[j-1].start;
//                        at[j].end = at[j-1].end;
//                        at[j].spare = at[j-1].spare;
//                        at[j].flag = 1;
                        this.atc[j].start = this.atc[j-1].start;
                        this.atc[j].end = this.atc[j-1].end;
                        this.atc[j].spare = this.atc[j-1].spare;
                        this.atc[j].flag = this.atc[j-1].flag;
                    }
                    //第二个新节点
                    this.atc[i+1].setAvailTime(taskavailtime + taskneedtime,this.atc[i].end);
//                    at[i+1].start = taskavailtime + taskneedtime;
//                    at[i+1].end =at[i].end;
//                    at[i+1].spare = at[i+1].end - at[i+1].start;
//                    at[i+1].flag = 1;
                    //第一个新节点
                    this.atc[i].setAvailTime(this.atc[i].start,taskavailtime);
//                    at[i].end = taskavailtime;
//                    at[i].spare = at[i].end - at[i].start;
//                    at[i].flag = 1;
                    AST = taskavailtime;//返回值
                    select = 1;
                    break;
                }
            }
            i++;
        }//while循环结束
//        System.err.println(Arrays.asList(atc));
        if(select == 0){//没命中，进行末端处理
            if(taskavailtime <= this.timerange) {//任务已到达末端直接跟进
                AST = this.timerange;//返回值
                this.timerange += taskneedtime;
            }else{//任务没到达，末端产生空闲
                this.atc[i].setAvailTime(this.timerange,taskavailtime);
//                this.atc[i].start = timerange;
//                this.atc[i].end = taskavailtime;
//                this.atc[i].spare = this.atc[i].end - this.atc[i].start;
//                this.atc[i].flag = 1;
                this.timerange = taskavailtime + taskneedtime;
                AST = taskavailtime;//返回值
            }
        }
        return AST;
    }


    //new出来
    public void newServerTime(){
        this.timerange = 0;
        for (int i = 0; i < this.atc.length; i++) {
            AvailTime availtimetimeobject = new AvailTime();
            this.atc[i] = availtimetimeobject;//给空闲数组中每个空闲时间段new一个对象
            this.atc[i].initAvailTime();
        }
    }
    //初始化归0
    public void initServerTime(){
        this.timerange = 0;
        for (int i = 0; i < this.atc.length; i++) {
            this.atc[i].initAvailTime();
        }
    }
    //复制服务器时间信息
    public void copyServerTime(ServerTime st){
        this.timerange = st.timerange;
        for (int i = 0; i < this.atc.length; i++) {
            this.atc[i].copyAvailTime(st.atc[i]);
        }
    }

}
