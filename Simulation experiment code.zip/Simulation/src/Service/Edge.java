package Service;

public class Edge {
    double communication;

    //初始化归0
    public void initEdge(){
        this.communication = 0;
    }

    //复制edge
    public void copyEdge(Edge edge){
        this.communication = edge.communication;
    }

}
