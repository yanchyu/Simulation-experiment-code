package Service;

public class DOffload {
    public double[] Exe(int tasknumber,int servernumber,DAG dag,ServerCluster servercluster,double[][] struct){//返回AFT
        double taskneedtime = struct[tasknumber][servernumber]*dag.subtask[tasknumber].calculation;
        double taskavailtime = 0;
        //找taskavailtime
        double temp = 0;
        int predtaskname = 0;
        int predtaskserver = 0;
        if(dag.subtask[tasknumber].prednodenum == 0){
            taskavailtime = 0;
        }else{
            taskavailtime = -999999;
            for (int i = 1; i <= dag.subtask[tasknumber].prednodenum; i++) {
                double minavail = 999999;
                int select = 0;//前置任务第几个服务器
                for (int j = 0; j <= dag.subtask[dag.subtask[tasknumber].prednode[i]].exedservernum; j++) {
                    if(servernumber == dag.subtask[dag.subtask[tasknumber].prednode[i]].exedservername[j]){
                        temp = dag.subtask[dag.subtask[tasknumber].prednode[i]].AFT[j];
                    }else{
                        temp = dag.subtask[dag.subtask[tasknumber].prednode[i]].AFT[j] + dag.edge[dag.subtask[tasknumber].prednode[i]][tasknumber].communication;
                    }
                    if(minavail > temp){
                        minavail = temp;
                        predtaskname = dag.subtask[tasknumber].prednode[i];
                        select = j;
                    }
                }
                if(minavail > taskavailtime){
                    taskavailtime = minavail;
                    predtaskname = dag.subtask[tasknumber].prednode[i];
                    predtaskserver = dag.subtask[dag.subtask[tasknumber].prednode[i]].exedservername[select];
                }
            }
        }

        double AST = servercluster.server[servernumber].servertime.atCexe(taskneedtime,taskavailtime);
        double AFT = AST + taskneedtime;
        double[] AT = {AST,AFT,predtaskname,predtaskserver};//0代表开始时间，1代表结束时间，2代表关键父节点，3代表关键父节点所在的服务器
        return AT;
    }


}

