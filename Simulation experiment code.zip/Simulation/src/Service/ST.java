package Service;

public class ST {

    public double STexe(DAG dag,ServerCluster servercluster,double[][] struct) {
        double min = 99999999;
        for (int j = 1; j <= servercluster.servernum; j++) {
            double sum = 0;
            for (int i = 1; i <= dag.subtasknum ; i++) {
                sum += struct[i][j]*dag.subtask[i].calculation;
            }
            if (sum < min){
                min = sum;
            }
        }
        return min;
    }
}
