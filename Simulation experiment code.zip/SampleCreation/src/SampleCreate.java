import javax.sql.rowset.serial.SerialBlob;
import java.sql.*;
import java.util.Random;

public class SampleCreate {
    public static void main(String[] args) throws Exception {
        //数据库连接
        Class.forName("com.mysql.cj.jdbc.Driver");
        String url = "jdbc:mysql://127.0.0.1:3306/sample";
        String username = "root";
        String password = "12345";
        Connection conn = DriverManager.getConnection(url,username,password);
        PreparedStatement ps = null;

        //参数输入
        int[] tasknumarray = {10,20,30,40,50,60,70,80,90,100};
        int[] servernumarray = {5,10,15,20,25};//大
        double[] ccrarray = {0.2,0.5,1,2,5};//小
        double[] rangearray = {0.5,1,1.5};//大
        double[] fatarray = {0.3,0.5,0.7};//小
        double[] densityarray = {0.4,0.6};//小
        int tasknum,servernum;
        double ccr,range,fat,density;

        int edgevalue = 500;
        double[] edgecost = {0};
        int subtaskvalue = 0;

        //辅助变量
        String tablename;
        String sql_create,sql_insert;
        String structstring;
        Blob dagstring;

        //样本数
        int dagnum = 100;
        for (int tn = 0; tn < 10 ; tn++) {//子任务数量450
            tasknum = tasknumarray[tn];
            for (int sn = 4; sn < 5; sn++) {//服务器数量90
                servernum = servernumarray[sn];
                for (int c = 0; c < 5; c++) {//ccr18
                    ccr = ccrarray[c];
                    for (int f = 0; f < 3; f++) {//fat
                        fat = fatarray[f];
                        for (int d = 0; d < 2; d++) {//density
                            density = densityarray[d];
                            for (int r = 0; r < 3; r++) {//range
                                range = rangearray[r];
                                /**************************************************/
                                //建表
                                tablename = "tn" + tasknum + "_sn" + servernum + "_c" + (int)(ccr*10) + "_r" + (int)(range*10) + "_f" + (int)(fat*10) + "_d" + (int)(density*10);
                                sql_create = "create table " + tablename + " (id int primary key auto_increment,subtasknum int,servernum int,dagstring Blob,structstring varchar(16000)," +
                                        "cp double,st double,a1 double,a2 double,a3 double,a4 double,a5 double,a6 double,a7 double,a8 double,a9 double,a10 double)";
                                ps = conn.prepareStatement(sql_create);
                                ps.execute();
                                for (int num = 0; num < dagnum; num++) {
                                    //生成DAG
                                    dagstring = DAGcreate(tasknum,edgevalue,ccr, fat, density,conn,ps,edgecost);
                                    //计算对应服务集群参数
                                    subtaskvalue = (int)(edgevalue*ccr*2);
                                    //生成struct
                                    structstring = Structcreate(tasknum,servernum,subtaskvalue,range,conn,ps);
                                    //存储
                                    sql_insert = "insert into " + tablename + " (subtasknum,servernum,dagstring,structstring)" + " values(?,?,?,?)";
                                    ps = conn.prepareStatement(sql_insert);
                                    ps.setInt(1,tasknum);
                                    ps.setInt(2,servernum);
                                    ps.setBlob(3,dagstring);
                                    ps.setString(4,structstring);
                                    ps.execute();
                                }
                                /**************************************************/
                            }//range
                        }//density
                    }//fat
                    System.out.println("" + tn + " " + sn + " " + c);
                }//ccr
            }//服务器数量
        }//子任务数量

        //断开连接
        ps.close();
        conn.close();
    }


    //生成区间内随机数（包括区间两侧）
    public static int r(int i,int j){
        Random r = new Random();
        return r.nextInt(j-i+1)+i;
    }


    //转换为字符串
    public static String MathrixToString(int[][] dag,int nodenum){
        String st = "";
        for (int i = 0; i <= nodenum; i++) {
            for (int j = 0; j <= nodenum ; j++) {
                int num = dag[i][j];
                String[] ch = {"0","0","0"};
                for (int k = 2; k >= 0; k--) {
                    ch[k] =  String.valueOf(num%10);
                    num = num/10;
                }
                for (int k = 0; k <= 2; k++) {
                    st = st + ch[k];
                }
            }
        }
        return st;
    }
    //struct版
    public static String Mathrix2String4struct(int[][] struct){
        String st = "";
        for (int i = 0; i < struct.length; i++) {
            for (int j = 0; j < struct[0].length ; j++) {
                int num = struct[i][j];
                String[] ch = {"0","0","0","0","0"};//5个数字
                for (int k = 4; k >= 0; k--) {
                    ch[k] =  String.valueOf(num%10);
                    num = num/10;
                }
                for (int k = 0; k <= 4; k++) {
                    st = st + ch[k];
                }
            }
        }
        return st;
    }

    //初始化数组
    public static void InitMatrix(int[][] matrix){
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[0].length; j++) {
                matrix[i][j] = 0;
            }
        }
    }
    public static void InitMatrix(double[][] matrix){
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[0].length; j++) {
                matrix[i][j] = 0;
            }
        }
    }

    //为子任务或服务器赋值
    public static void NodeValue(int[][] matrix){
        for (int i = 1; i <= matrix.length-1; i++) {
            matrix[0][i] = 1;
        }
    }

    //生成DAG并存入数据库
    public static Blob DAGcreate(int subtasknum,int edgevalue,double ccr,double fat,double density,Connection conn,PreparedStatement ps,double[] edgecost) throws Exception {
        int[][] dag = new int[subtasknum+1][subtasknum+1];
        InitMatrix(dag);
        NodeValue(dag);
        EdgeCreate(dag, dag.length-3,fat,density);
        edgecost[0] = EdgeValue(dag, edgevalue);
        //转为字符串和Blob形式
        String dagstring = MathrixToString(dag,subtasknum);
        Blob b = new SerialBlob(dagstring.getBytes("utf-8"));

        return b;
    }
    //边缘生成
    public static int EdgeCreate(int[][] dag,int stnum,double fat,double density){
        //确定多少级
        double x = Math.sqrt(stnum)/fat;
        int ranknum = (int)x;
        if(x-ranknum > 0.5){
            ranknum++;
        }
        if(ranknum > stnum){
            ranknum = stnum;
        }
//        int y = r(1,100);
//        if(y < (x-ranknum)*100){
//            ranknum += 1;
//        }
        //确定每级任务数
        int[] rank = new int[ranknum+1];//从下标1开始，rank[1]到rank[ranknum]
        //基础任务数
        int z = (int)((double)stnum/(ranknum));
        if((double)stnum/(ranknum)-z > 0.5 && (z+1)*ranknum <= stnum){
            z++;
        }
        for (int i = 1; i <= ranknum; i++) {
            rank[i] = z;
        }
        //额外任务数
        for (int i = 1; i <= (stnum - z*ranknum) ; i++) {
            rank[r(1,ranknum)]++;
        }

        //生成边
        int edgesum = 0;//边总数
        int prednum = 0;//前面的结点数
        for (int i = 1; i <= ranknum-1; i++) {//i为当层第一级
            //确定层级之间边缘数
            int low = rank[i] + rank[i+1];
            int high = rank[i]*rank[i+1];
//            int edgenum = low + (int)(density*(high - low));
            int edgenum = (int)(density * high) + 1;
            edgesum += edgenum;
            //连接基础边缘
            int numed = 0;//已有边数
            //上层连接后继结点
            for (int j = 1; j <= rank[i] ; j++) {
                int succ = r(1,rank[i+1]);

                if(i <= ranknum - 2){
                    succ = r(1,rank[i+1]+rank[i+2]);
                }//隔两层

                if(i <= ranknum - 3){
                    succ = r(1,rank[i+1]+rank[i+2]+rank[i+3]);
                }//隔三层

                dag[prednum+j+1][prednum + rank[i] + succ+1] = 1;
                numed++;
            }

            //下层连接前驱结点
            for (int j = 1; j <= rank[i+1] ; j++) {
                //检查是否已有前驱
                int tag = 0;
                for (int k = prednum+1; k <= prednum+rank[i] ; k++) {
                    if (dag[k+1][prednum + rank[i] + j+1] == 1) {
                        tag = 1;
                    }
                }
                if(tag == 1){
                    continue;
                }
                int pred = 0;
                if(i == 1) {
                    if(rank[i] == 0)
                    pred = r(1, rank[i]);
                    dag[prednum + pred + 1][prednum + rank[i] + j + 1] = 1;
                }
                if(i>=2){
                    pred = r(1,rank[i]+rank[i-1]);
                    dag[prednum - rank[i-1] + pred + 1][prednum + rank[i] + j+1] = 1;
                }//隔两个找前驱
                if(i>=3){
                    pred = r(1,rank[i]+rank[i-1]+rank[i-2]);
                    dag[prednum - rank[i-1] - rank[i-2] + pred + 1][prednum + rank[i] + j+1] = 1;
                }//隔三个找前驱
                numed++;
            }

            //连接额外结点
            while (numed<edgenum) {
                int pred = r(1, rank[i]);
                int succ = r(1,rank[i+1]);

                if(i <= ranknum - 2){
                    succ = r(1,rank[i+1]+rank[i+2]);
                }//隔两层

                if(i <= ranknum - 3){
                    succ = r(1,rank[i+1]+rank[i+2]+rank[i+3]);
                }//隔三层

                if(dag[prednum+pred+1][prednum+rank[i]+succ+1] != 1){
                    dag[prednum+pred+1][prednum+rank[i]+succ+1] = 1;
                    numed++;
                }
            }
            prednum += rank[i];
        }//层级结束

        //连接首结点
        for (int i = 1; i <= rank[1] ; i++) {
            dag[1][i+1] = 1;
            edgesum++;
        }
        //连接尾结点
        for (int i = 1; i <= rank[ranknum] ; i++) {
            dag[dag.length-1-i][dag.length-1] = 1;
            edgesum++;
        }
        return edgesum;
    }
    //为edge赋值
    public static double EdgeValue(int[][] dag,int valuerange){
        double edgecost = 0;
        for (int i = 1; i <= dag.length-1; i++) {
            for (int j = i+1; j <= dag.length-1; j++) {
                if(dag[i][j]!=0){
                    dag[i][j] = r(1,valuerange);
                    edgecost += dag[i][j];
                }
            }
        }
        return edgecost;
    }

    //生成struct并存入数据库
    public static String Structcreate(int subtasknum,int servernum,int subtaskvalue,double range,Connection conn,PreparedStatement ps) throws Exception {
        //开始生成struct
        Random random = new Random();
        int[][] struct = new int[subtasknum+1][servernum+1] ;//都从1开始计数
        InitMatrix(struct);
        //生成struct矩阵
        double subtaskcost;
        for (int i = 1; i <= subtasknum ; i++) {
            subtaskcost = random.nextInt(subtaskvalue) + 1;
            for (int j = 1; j <= servernum ; j++) {
                int flag = random.nextInt(100)+1;
                double coe = (double)(random.nextInt((int)(range*100))+1)/100;
                if(flag <= 50){
                    struct[i][j] = (int)((1 - coe/2)*subtaskcost);
                }
                if(flag >= 51){
                    struct[i][j] = (int)((1 + coe/2)*subtaskcost);
                }
            }
        }
        //转为字符串形式
        String structstring = Mathrix2String4struct(struct);

        return structstring;
    }

    //输出DAG图
    public static void print(int dag[][]){
        for (int i = 0; i < dag.length; i++) {
            for (int j = 0; j < dag[0].length; j++) {
                System.out.print(dag[i][j]+" ");
            }
            System.out.print("\n");
        }
    }
}


